import re
import discord
from discord.ext import commands
import logging
import requests
import urllib.parse

# Set up logging
logging.basicConfig(level=logging.INFO)

# Replace with your actual Discord bot token
DISCORD_API_TOKEN = 'discord_bot_token'

# Replace with your actual Server ID and Channel IDs
SERVER_ID = discord_server_id
GENERAL_CHANNEL_ID = general_channel_id
ADD_BADWORDS_CHANNEL_ID = the_channel_you_want_to_add_bad_words

# Change user with the username on your pc, the history file is where all google look ups are saved. !Dont change anything else!
HISTORY_FILE = 'C:/Users/User/Desktop/discordBOT/history.txt'
BAD_WORDS_FILE = 'C:/Users/user/Desktop/discordBOT/badwords.txt'

# this dosnt matter its a deleted function
TENOR_API_KEY = 'DELETED_your_tenor_api_key_here_DELETED'

intents = discord.Intents.default()
intents.messages = True  
intents.message_content = True  

bot = commands.Bot(command_prefix="+", intents=intents)

bad_words = []

def load_bad_words():
    global bad_words
    try:
        with open(BAD_WORDS_FILE, 'r') as file:
            bad_words = [line.strip() for line in file.readlines() if line.strip()]
    except FileNotFoundError:
        logging.error(f"Bad words file ({BAD_WORDS_FILE}) not found. Creating new file.")
    except Exception as e:
        logging.error(f"Error loading bad words: {e}")

def save_bad_words():
    try:
        with open(BAD_WORDS_FILE, 'w') as file:
            file.write('\n'.join(bad_words))
    except Exception as e:
        logging.error(f"Error saving bad words to {BAD_WORDS_FILE}: {e}")

def filter_bad_words(message):
    for word in bad_words:
        message = re.sub(rf'\b{word}\b', '*' * len(word), message, flags=re.IGNORECASE)
    return message

def save_to_history(user, query):
    try:
        with open(HISTORY_FILE, 'a') as file:
            file.write(f"@{user} {query}\n{'-' * 70}\n")
    except Exception as e:
        logging.error(f"Error saving to history.txt: {e}")

@bot.event
async def on_ready():
    try:
        print(f'Bot is ready and logged in as {bot.user}')
        load_bad_words()
    except Exception as e:
        logging.error(f"Error in on_ready: {e}")

@bot.command()
async def math(ctx, *, equation):
    """Perform mathematical calculations."""
    try:
        result = eval(equation)
        await ctx.send(f'{equation} = {result}')
    except Exception as e:
        await ctx.send(f'Error: {e}')

@bot.command()
async def google(ctx, *, query):
    """Search for information on Google."""
    try:
        if is_bad_word(query):
            await ctx.send("Sorry, I cannot search for that query due to content restrictions.")
        else:
            encoded_query = urllib.parse.quote_plus(query)
            search_url = f'https://www.google.com/search?q={encoded_query}'
            await ctx.send(f'Google search result: {search_url}')
            
            save_to_history(ctx.author.display_name, query)
            
    except Exception as e:
        await ctx.send(f'Error: {e}')

@bot.command(aliases=['abw'])
async def addbadword(ctx, *, word):
    """Add a bad word to filter (restricted to ADD_BADWORDS_CHANNEL_ID)."""
    try:
        if ctx.channel.id != ADD_BADWORDS_CHANNEL_ID:
            await ctx.send("You can only add bad words in the bad words channel.")
            return

        word = word.lower()
        if word not in bad_words:
            bad_words.append(word)
            save_bad_words()  
            await ctx.send(f'Added "{word}" to bad words list.')
        else:
            await ctx.send(f'"{word}" is already in bad words list.')
    except Exception as e:
        await ctx.send(f"Error adding bad word: {e}")

@bot.command(aliases=['rbw'])
async def removebadword(ctx, *, word):
    """Remove a bad word from filter (restricted to ADD_BADWORDS_CHANNEL_ID)."""
    try:
        if ctx.channel.id != ADD_BADWORDS_CHANNEL_ID:
            await ctx.send("You can only remove bad words in the bad words channel.")
            return

        word = word.lower()
        if word in bad_words:
            bad_words.remove(word)
            save_bad_words()  
            await ctx.send(f'Removed "{word}" from bad words list.')
        else:
            await ctx.send(f'"{word}" is not in bad words list.')
    except Exception as e:
        await ctx.send(f"Error removing bad word: {e}")

@bot.event
async def on_message(message):
    try:
        if message.author == bot.user:
            return

        if message.channel.id != ADD_BADWORDS_CHANNEL_ID:
            filtered_content = filter_bad_words(message.content)
            if filtered_content != message.content:
                await message.delete()
                await message.channel.send(f'{message.author.mention}, watch your language!')
                logging.info(f'Deleted message from {message.author.display_name}: {message.content}')
    except Exception as e:
        logging.error(f"Error processing message: {e}")

    await bot.process_commands(message)

def is_bad_word(query):
    """Check if the query is in the bad words list."""
    for word in bad_words:
        if word.lower() in query.lower():
            return True
    return False

bot.run(DISCORD_API_TOKEN)


 # __  __    _    ____  _____   ______   __  __  __  ___ _____ _____        _____ ____  _ ____  _____ 
 # |  \/  |  / \  |  _ \| ____| | __ ) \ / / |  \/  |/ _ \_   _/ _ \ \      / /_ _/ ___|/ |___ \|___ / 
 # | |\/| | / _ \ | | | |  _|   |  _ \\ V /  | |\/| | | | || || | | \ \ /\ / / | |\___ \| | __) | |_ \ 
 # | |  | |/ ___ \| |_| | |___  | |_) || |   | |  | | |_| || || |_| |\ V  V /  | | ___) | |/ __/ ___) |
 # |_|  |_/_/   \_\____/|_____| |____/ |_|   |_|  |_|\___/ |_| \___/  \_/\_/  |___|____/|_|_____|____/ 